(function () {
    'use strict';

    let colorPickerActive = false;

    /**
     * A simple, self-contained debounce function. We use this because the game's
     * built-in Lodash library (_) is not reliably available in all modded versions.
     * @param {Function} func The function to debounce.
     * @param {number} wait The delay in milliseconds.
     * @returns {Function} The new debounced function.
     */
    function HGP_debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    };

    // Define updateMannequin immediately using our own debounce function.
    const updateMannequin = HGP_debounce(() => {
        if ($('#mannequin').length) {
            $.wiki('<<replace "#mannequin">><<mannequinHairdresser>><</replace>>');
        }
    }, 150); // A slightly longer delay can also help prevent issues.


    $(document).one(':passageinit', function () {
        if (V.hgpCustomColors === undefined) {
            V.hgpCustomColors = {};
        }
        if (V.hgpOriginalColors === undefined) {
            V.hgpOriginalColors = {};
            Object.keys(setup.colours.hair_map).forEach(key => {
                const colorDef = setup.colours.hair_map[key];
                if (colorDef?.canvasfilter?.blend) {
                    V.hgpOriginalColors[key] = colorDef.canvasfilter.blend;
                }
            });
        }
    });

    $(document).one(':storyready', function () {
        if (V.hgpCustomColors && Object.keys(V.hgpCustomColors).length > 0) {
            HGP_restoreCustomColors();
        }
    });

    $(document).on(':passagestart', function () {
        if (V.hgpCustomColors && Object.keys(V.hgpCustomColors).length > 0) {
            HGP_restoreCustomColors();
        }
    });

    window.HGP_restoreCustomColors = function () {
        Object.keys(V.hgpCustomColors).forEach(dyeVariable => {
            const color = V.hgpCustomColors[dyeVariable];
            const colorDef = setup.colours.hair_map[dyeVariable];

            if (!colorDef?.canvasfilter) {
                console.warn(`HGP: Cannot restore color for ${dyeVariable}, colorDef not found`);
                return;
            }

            colorDef.canvasfilter.blend = color;
            colorDef.canvasfilter.blendMode = "hard-light";
        });
    };

    window.HGP_updateColor = function (dyeVariable, newColor) {
        V.hgpCustomColors[dyeVariable] = newColor;

        const colorDef = setup.colours.hair_map[dyeVariable];
        if (colorDef?.canvasfilter) {
            colorDef.canvasfilter.blend = newColor;
            colorDef.canvasfilter.blendMode = "hard-light";
        } else {
            console.warn(`HGP: Cannot update color for ${dyeVariable}, colorDef not found`);
        }

        $(`.hgp-clickable-swatch[data-dye-variable="${dyeVariable}"] .colour-hair`)
            .css('background-color', newColor);

        updateMannequin();
    };

    window.HGP_resetColor = function (dyeVariable) {
        delete V.hgpCustomColors[dyeVariable];

        const originalColor = V.hgpOriginalColors?.[dyeVariable] || '#fd6064';

        const colorDef = setup.colours.hair_map[dyeVariable];
        if (colorDef?.canvasfilter) {
            colorDef.canvasfilter.blend = originalColor;
        } else {
            console.warn(`HGP: Cannot reset color for ${dyeVariable}, colorDef not found`);
        }

        $(`.hgp-clickable-swatch[data-dye-variable="${dyeVariable}"] .colour-hair`)
            .css('background-color', originalColor);

        updateMannequin();
    };

    $(document).on('click', '.hgp-clickable-swatch', function (e) {
        if (colorPickerActive) return;

        const dyeVariable = this.dataset.dyeVariable;
        const currentColor = V.hgpCustomColors[dyeVariable] ||
            setup.colours.hair_map[dyeVariable]?.canvasfilter?.blend ||
            '#FF0000';

        colorPickerActive = true;

        const $picker = $('<input type="color">')
            .val(currentColor)
            .css({ position: 'absolute', opacity: 0, 'pointer-events': 'none' })
            .appendTo('body')
            .on('input', function () {
                window.HGP_updateColor(dyeVariable, this.value.toUpperCase());
            })
            .on('change blur', function () {
                $(this).remove();
                colorPickerActive = false;
            });

        $picker.trigger('click');
    });

    $(document).on('click', '.hgp-reset-btn', function (e) {
        e.stopPropagation();
        const dyeVariable = this.dataset.dye;
        window.HGP_resetColor(dyeVariable);
    });

    $(document).on('input change', '.hgp-slider, .hgp-dropdown', function () {
        if (this.matches('.hgp-slider')) {
            const slider = $(this);
            const channel = slider.data('channel');
            const prop = slider.data('prop');
            if (V.hgpCustom?.[channel]) {
                V.hgpCustom[channel][prop] = Number(slider.val());
            }
            slider.next('span').text(slider.val());
        }

        updateMannequin();
    });
})();