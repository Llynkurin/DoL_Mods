(function () {
    'use strict';
    function HGP_clone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }

    const AVAILABLE_PATTERNS = [
        'low-ombre',
        'high-ombre',
        'split',
        'face-frame',
        'scene-fade',
        'checker-fade',
        'wink-color'
    ];

    window.HGP_getAvailablePatterns = () => AVAILABLE_PATTERNS;

    $(document).one(':storyready', function () {
        const originalPatternProvider = Renderer.PatternProvider;
        const PATTERN_CANVAS_SIZE = 256;
        const patternCache = {};
        const maskCache = {};
        const MAX_PATTERN_CACHE = 50;

        function addToPatternCache(key, pattern) {
            const keys = Object.keys(patternCache);
            if (keys.length >= MAX_PATTERN_CACHE) {
                delete patternCache[keys[0]];
            }
            patternCache[key] = pattern;
        }

        function getMask(style) {
            const cached = maskCache[style];

            if (cached === 'loading') {
                return null;
            }

            if (cached instanceof HTMLImageElement) {
                return cached;
            }

            maskCache[style] = 'loading';

            const img = new Image();
            img.src = `img/hair/masks/hgp-defaults/${style}.png`;
            img.onload = () => {
                maskCache[style] = img;
            };
            img.onerror = () => {
                console.warn(`HGP: Failed to load mask for ${style}`);
                maskCache[style] = null;
            };

            return null;
        }

        AVAILABLE_PATTERNS.forEach(style => {
            const maskFileName = style.endsWith('-color') ? style.replace('-color', '') : style;
            getMask(maskFileName);
        });

        Renderer.PatternProvider = function (spec) {
            if (spec?.isHGPCustomPattern) {
                const { style, color1, color2 } = spec;
                const cacheKey = `${style}-${color1}-${color2}`;

                if (patternCache[cacheKey]) return patternCache[cacheKey];

                try {
                    const isColorMask = style.endsWith('-color');
                    const maskFileName = isColorMask ? style.replace('-color', '') : style;
                    const maskImg = getMask(maskFileName);

                    if (!maskImg) {
                        console.warn(`HGP: Mask not loaded yet for ${maskFileName}`);
                        return null;
                    }

                    if (isColorMask) {
                        const finalCanvas = Renderer.createCanvas(PATTERN_CANVAS_SIZE, PATTERN_CANVAS_SIZE);
                        finalCanvas.drawImage(maskImg, 0, 0, PATTERN_CANVAS_SIZE, PATTERN_CANVAS_SIZE);

                        const finalPattern = Renderer.globalC2D.createPattern(finalCanvas.canvas, 'repeat');
                        addToPatternCache(cacheKey, finalPattern);
                        return finalPattern;

                    } else {
                        const patternCanvas = document.createElement('canvas');
                        patternCanvas.width = PATTERN_CANVAS_SIZE;
                        patternCanvas.height = PATTERN_CANVAS_SIZE;
                        const patternCtx = patternCanvas.getContext('2d');

                        patternCtx.fillStyle = color2;
                        patternCtx.fillRect(0, 0, PATTERN_CANVAS_SIZE, PATTERN_CANVAS_SIZE);
                        patternCtx.globalCompositeOperation = 'destination-in';
                        patternCtx.drawImage(maskImg, 0, 0, PATTERN_CANVAS_SIZE, PATTERN_CANVAS_SIZE);

                        const finalCanvas = Renderer.createCanvas(PATTERN_CANVAS_SIZE, PATTERN_CANVAS_SIZE);
                        finalCanvas.fillStyle = color1;
                        finalCanvas.fillRect(0, 0, PATTERN_CANVAS_SIZE, PATTERN_CANVAS_SIZE);
                        finalCanvas.drawImage(patternCanvas, 0, 0);

                        const finalPattern = Renderer.globalC2D.createPattern(finalCanvas.canvas, 'repeat');
                        addToPatternCache(cacheKey, finalPattern);
                        return finalPattern;
                    }
                } catch (e) {
                    console.error("HGP Error creating pattern:", e);
                    return null;
                }
            }
            return originalPatternProvider(spec);
        };
    });

    window.HGP_createHairColourGradient = function (hairPart, gradient, hairType, hairLength, prefilterName) {
        if (!gradient?.style || !gradient.colours || gradient.colours.length < 2 ||
            !AVAILABLE_PATTERNS.includes(gradient.style)) {
            return window.createHairColourGradient_ORIGINAL(...arguments);
        }

        const color1Data = setup.colours.hair_map[gradient.colours[0]];
        const color2Data = setup.colours.hair_map[gradient.colours[1]];

        if (!color1Data?.canvasfilter?.blend || !color2Data?.canvasfilter?.blend) {
            return window.createHairColourGradient_ORIGINAL(...arguments);
        }

        const patternSpec = {
            isHGPCustomPattern: true,
            style: gradient.style,
            color1: color1Data.canvasfilter.blend,
            color2: color2Data.canvasfilter.blend
        };
        
        // Use our self-contained clone function here
        const baseFilter = HGP_clone(setup.colours.sprite_prefilters[prefilterName]);
        Renderer.mergeLayerData(baseFilter, {
            blend: { pattern: patternSpec },
            blendMode: "hard-light"
        }, true);

        const finalBrightness = Math.min(
            color1Data.canvasfilter.brightness || 0,
            color2Data.canvasfilter.brightness || 0
        );
        if (finalBrightness !== 0) {
            baseFilter.brightness = (baseFilter.brightness || 0) + finalBrightness;
        }

        return baseFilter;
    };
})();